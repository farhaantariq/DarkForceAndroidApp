package com.example.farha.darkforce;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class Selection extends AppCompatActivity {

    private Button tictactoe, callmsg, geoloc, logout;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        setupUIViews();
        firebaseAuth = FirebaseAuth.getInstance();

        tictactoe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Selection.this, com.example.farha.darkforce.tictactoe.class));
            }
        });

        callmsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Selection.this, com.example.farha.darkforce.callmsg.class));
            }
        });

        geoloc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Selection.this, Geoloc.class));
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Toast.makeText(Selection.this, "Signed Out Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Selection.this, MainActivity.class));
            }
        });


    }

    private void setupUIViews(){
        tictactoe = (Button)findViewById(R.id.btntictactoe);
        callmsg = (Button)findViewById(R.id.btncallmsg);
        geoloc = (Button)findViewById(R.id.btnGeoloc);
        logout = (Button)findViewById(R.id.btnlogout);
    }
}
