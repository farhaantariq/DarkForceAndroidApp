package com.example.farha.darkforce;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class UserRegister extends AppCompatActivity {

    private EditText userName, userEmail, userPassword;
    private Button regButton;
    private TextView alreadyRegister;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);

        setupUIViews();

        firebaseAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

        regButton.setOnClickListener(new View.OnClickListener() {



            @Override
            public void onClick(View v) {

                progressDialog.setMessage("Impressive...Most Impressive...Farhaan has taught you well!");
                progressDialog.show();

                if(validate()){
                    //Upload this data to the database
                    String useremail = userEmail.getText().toString().trim();
                    String userpassword = userPassword.getText().toString().trim();

                    firebaseAuth.createUserWithEmailAndPassword(useremail, userpassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                progressDialog.dismiss();
                            Toast.makeText(UserRegister.this, "New User Created, Registration Successful!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(UserRegister.this, MainActivity.class));
                            }else {
                                progressDialog.dismiss();
                                Toast.makeText(UserRegister.this, "User Already Exists, Registration Failed!!!", Toast.LENGTH_SHORT).show();
                            }
                    }
                    });
                }
            }
        });

        alreadyRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserRegister.this, UserLogin.class));
            }
        });

    }

    private void setupUIViews(){
        userName = (EditText)findViewById(R.id.etUserName);
        userEmail = (EditText)findViewById(R.id.etUserEmail);
        userPassword = (EditText)findViewById(R.id.etUserPassword);
        regButton = (Button)findViewById(R.id.btnUserRegister);
        alreadyRegister = (TextView)findViewById(R.id.tvAlreadyRegistered);
    }

    private Boolean validate(){
        Boolean result = false;

        String name = userName.getText().toString();
        String password = userPassword.getText().toString();
        String email = userEmail.getText().toString();

        if(name.isEmpty() || password.isEmpty() || email.isEmpty()){
            progressDialog.dismiss();
            Toast.makeText(this, "Please Enter All Details", Toast.LENGTH_SHORT).show();
        }else {
            result = true;
        }

        return result;
    }
}
